#include <iostream>
#include "Tasks.h"

int main() {
    Task1();
    Task2();///
    Task3();
    Task4();
    Task5();
    Task6();
    Task7();
    Task8();
    Task9();
    Task10();
    return 0;
}
